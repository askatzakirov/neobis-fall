function list() {
	var tasks = ['Buy lemonade', 'Make toasts', 'Repair car', 'Play games', 'Pet a cat'];
	let element = document.getElementById('todo-list');
	let elem = getElementByClassName('task');
	let ol = document.createElement("ol");
	let li = document.createElement("li");
	for(let i = 0; i<tasks.length-1; i++){
		element.appendChild(li);
	}
	element.appendChild(ol);
}