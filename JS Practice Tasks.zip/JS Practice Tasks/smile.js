var smile = document.getElementById("smile");



drawface(smile, {
    fill: '#fff000',
    x: smile.width / 3,
    y: smile.height / 3,
    radius : 100
});

function draw_face(smile, option) {
    var ctx = smile.getContext("2d");
    ctx.save();
    ctx.lineWidth = option.radius * 0.090;
    ctx.strokeStyle = option.lineColor;
    ctx.beginPath();
    ctx.arc(option.x, option.y, option.radius, option.startAngle, option.endAngle);
    ctx.stroke();
    ctx.fillStyle = option.fill;
    ctx.fill();
    ctx.restore();
}

function drawSmile(smile, option, flipSmile) {
    var ctx = smile.getContext("2d");
    var radius = 40 * option.radius * 0.0150;
    var x = option.x;
    var y, startAngle, endAngle;
        
    if (flipSmile) {
        y = option.y + option.radius * 0.10;
        startAngle = -Math.PI * 0.100; //Math.PI * 0.1;
        endAngle = -0.5; //-Math.PI * 1.1;
    } else {
        y = option.y + option.radius * 0.1;
        startAngle = Math.PI * 0.1;
        endAngle = -Math.PI * 1.1;
    }

    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, radius, startAngle, endAngle);
    ctx.lineWidth = option.radius * 0.05;

    ctx.strokeStyle = option.lineColor;
    ctx.stroke();
    ctx.restore();
}

function draw_eyes(smile, option) {
    var xOffset = option.radius * 0.5;
    var radius = option.radius * 0.15;

    draw_eye(smile, option, xOffset, 2, radius); // left eye
    draw_eye(smile, option, -xOffset, 0, radius); // right eye
}

function draw_eye(smile, options, x, y, radius) {
    var temp = smile.getContext("2d");

    temp .save();

    temp .translate(options.x, options.y - (options.radius / 3));
    temp .scale(0.5, 0.8);

    temp .beginPath();
    temp .arc(x, y, radius, 0, 2 * Math.PI, false);

    temp .fillStyle = options.lineColor;
    temp .fill();
    temp .lineWidth = radius * 2;
    temp .strokeStyle = options.lineColor;
    temp .stroke();
    
    temp .restore();
}

function drawface(smile, option, flip) {
    option = option || {};
    
    var defaultRadius = 40;
    var options = {
        x: option.x || (defaultRadius / 0.8),
        y: option.y || (defaultRadius / 0.8),
        radius: option.radius,
        startAngle: 0,
        endAngle: 4 * Math.PI,
        fill: option.fill || 'yellow',
        lineColor: option.lineColor || 'black'
    };
    
    draw_face(smile, options);
    draw_eyes(smile, options);
    drawSmile(smile, options, flip);
}